IKMC Lớp 9-10 - Những chuyên đề chọn lọc · 1.0.1
Native tht-tutorials/1 course: references existing bank UIDs; does not install or duplicate questions.
Import the course ZIP in Tutorials 0.6.8 with the original Grade 9-10 bank already installed.
Practice questions may reappear in their topic Mock; they are the same original questions, not copies.
Private audit and source mapping are outside this strict import ZIP.
