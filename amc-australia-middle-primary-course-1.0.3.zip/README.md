AMC Australia Middle Primary Course 1.0.3. Import in THT Tutorials, not in WordPress Plugins or question-bank ZIP import. Native question packages must be imported and published with unchanged UIDs.

Version 1.0.3: Revised English and Vietnamese wording for clarity and re-checked worked solutions. Lesson SHA-256 values updated; UIDs, bank references and Mock questions unchanged.
