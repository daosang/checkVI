# IKMC Grade 7-8 - Selected Topics

Course version 1.0.3, format tht-tutorials/1. Import this ZIP in THT Tutorials. It reuses existing question UIDs and does not create question-bank records. Keep existing source examinations and their assets installed.
