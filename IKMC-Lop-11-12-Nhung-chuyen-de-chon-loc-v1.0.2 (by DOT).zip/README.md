IKMC Lớp 11-12 - Những chuyên đề chọn lọc

Course UID: ikmc-g1112-selected
Version: 1.0.2

VI: Gói Course đã được kiểm tra cấu trúc, liên kết và nội dung trong phạm vi báo cáo đi kèm. Đã tạo và kiểm tra bản hiển thị cục bộ Anh–Việt. Chưa thử import trên website hoặc chứng nhận sẵn sàng xuất bản. Bộ kiểm tra gốc trả PASS_STRUCTURE_REVIEW_REQUIRED, ready_to_publish=false; các giới hạn và cảnh báo được giữ nguyên trong báo cáo ngoài ZIP.

EN: This Course package has local structure, reference and content checks within the accompanying report's stated scope. English/Vietnamese static previews have been generated and checked. Actual website import and publication readiness are not certified. The unchanged original validator returns PASS_STRUCTURE_REVIEW_REQUIRED, ready_to_publish=false; limitations and warnings remain in the external report.

VI: Cần THT core 1.9.32 và THT Tutorials 0.6.5 trở lên. Ngân hàng và hình nguồn phải được nhập riêng. Gói chỉ tham chiếu UID gốc, không tạo hay sao chép câu ngân hàng. Luyện tập và Mock có tái tham chiếu.

EN: Requires THT core 1.9.32 and THT Tutorials 0.6.5 or later. Original bank and assets must be imported separately. This Course references existing original UIDs only; it creates no bank questions. Practice and Mock intentionally reuse references.
