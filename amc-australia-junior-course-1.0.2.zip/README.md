AMC Australia Junior Course 1.0.1. Import in THT Tutorials, not in WordPress Plugins or question-bank ZIP import. Native question packages must be imported and published with unchanged UIDs.

Version 1.0.2: Adds ten topic illustrations (500x300 JPEG). Install Tutorials 0.6.4 and core1.9.31 first, then Update existing Course with same UID. All lesson bytes, bank references, Mock questions and answers unchanged.
